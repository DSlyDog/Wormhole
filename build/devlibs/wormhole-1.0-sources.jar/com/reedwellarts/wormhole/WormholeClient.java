package com.reedwellarts.wormhole;

import com.reedwellarts.wormhole.client.TestScreen;
import com.reedwellarts.wormhole.client.WormholeClientNetworking;
import com.reedwellarts.wormhole.items.ItemRegistrar;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemGroups;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class WormholeClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(ItemRegistrar.WORMHOLE_LINKER);
        });
        WormholeClientNetworking.register();

        KeyBinding testKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.wormhole.test",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                KeyBinding.Category.create(Identifier.of(Wormhole.MOD_ID, "keys"))
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (testKey.wasPressed()) {
                client.setScreen(new TestScreen());
            }
        });
    }
}
