package com.reedwellarts.wormhole.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class TestScreen extends Screen {
    public TestScreen() {
        super(Text.literal("Test"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        context.drawCenteredTextWithShadow(getTextRenderer(), "TEST", width / 2, 128, 0xFFFFFF);
    }
}
