package com.reedwellarts.wormhole.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.reedwellarts.wormhole.components.ModComponents;
import com.reedwellarts.wormhole.items.BlockRegistrar;
import com.reedwellarts.wormhole.portal.WormholeLinkState;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

import java.util.Map;

public class WormholeCommands {

    private WormholeCommands() {}

    public static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            register(dispatcher);
        });
    }

    private static void register(CommandDispatcher<ServerCommandSource> dispatcher){
        dispatcher.register(
                CommandManager.literal("wormhole")
                        .then(CommandManager.literal("list").executes(WormholeCommands::listPortals))
                        .then(CommandManager.literal("name")
                                .then(CommandManager.argument("name", StringArgumentType.word())
                                        .executes(WormholeCommands::namePortal)))
        );
    }

    private static int namePortal(CommandContext<ServerCommandSource> ctx){
        ServerCommandSource source = ctx.getSource();
        ServerPlayerEntity player = source.getPlayer();
        if (player == null){
            source.sendFeedback(() ->
                    Text.literal("This command can only be used by players").formatted(Formatting.RED), false);
            return 0;
        }

        ItemStack held = player.getMainHandStack();
        BlockPos pending = held.get(ModComponents.PENDING_PORTAL_PS);
        if (pending == null){
            source.sendFeedback(() ->
                    Text.literal("No portal base selected. Right-click a portal base with the Wormhole Linker first.")
                            .formatted(Formatting.RED),
                    false);
            return 0;
        }

        String name = StringArgumentType.getString(ctx, "name");
        ServerWorld world = source.getWorld();

        if (!world.getBlockState(pending).isOf(BlockRegistrar.WORMHOLE_PORTAL_BASE)){
            source.sendFeedback(() ->
                    Text.literal("The selected block is no longer a portal base")
                            .formatted(Formatting.RED),
                    false);
            held.remove(ModComponents.PENDING_PORTAL_PS);
            return 0;
        }

        WormholeLinkState.get(world).registerPortal(name, pending);
        held.remove(ModComponents.PENDING_PORTAL_PS);

        source.sendFeedback(() ->
                Text.literal("Portal registered as '" + name + "' at " + pending.toShortString())
                        .formatted(Formatting.GREEN),
                false);
        return 1;
    }

    private static int listPortals(CommandContext<ServerCommandSource> ctx){
        ServerCommandSource source = ctx.getSource();
        ServerWorld world = source.getWorld();
        WormholeLinkState state = WormholeLinkState.get(world);

        Map<String, BlockPos> portals = state.allPortals();
        if (portals.isEmpty()){
            source.sendFeedback(() ->
                    Text.literal("No portals registered in this dimension")
                            .formatted(Formatting.RED),
                    false);
            return 0;
        }

        portals.forEach((name, pos) ->
                source.sendFeedback(() ->
                        Text.literal(" '" + name + "' → " + pos.toShortString())
                                .formatted(Formatting.AQUA),
                        false));

        source.sendFeedback(() ->
                Text.literal("Total: " + portals.size() + " portal(s)")
                        .formatted(Formatting.YELLOW),
                false);
        return portals.size();
    }
}
