package com.reedwellarts.wormhole.items.blocks;

import net.minecraft.block.Block;

public class WormholePortalFrameBlock extends Block {

    public WormholePortalFrameBlock(Settings settings){
        super(settings);
    }
}
