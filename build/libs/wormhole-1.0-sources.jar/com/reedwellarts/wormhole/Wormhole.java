package com.reedwellarts.wormhole;

import com.reedwellarts.wormhole.command.WormholeCommands;
import com.reedwellarts.wormhole.components.ModComponents;
import com.reedwellarts.wormhole.items.BlockRegistrar;
import com.reedwellarts.wormhole.items.ItemRegistrar;
import com.reedwellarts.wormhole.network.WormholeServerNetworking;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Wormhole implements ModInitializer {

    public static final String MOD_ID = "wormhole";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Wormhole mod is initializing");

        ItemRegistrar.registerModItems();
        BlockRegistrar.registerModBlocks();
        ModComponents.registerModComponents();
        WormholeCommands.registerCommands();
        WormholeServerNetworking.register();

        LOGGER.info("Wormhole mod loaded");
    }
}
