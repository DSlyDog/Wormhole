package com.reedwellarts.wormhole;

import com.reedwellarts.wormhole.client.WormholeClientNetworking;
import com.reedwellarts.wormhole.items.ItemRegistrar;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_7706;

public class WormholeClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> {
            entries.method_45421(ItemRegistrar.WORMHOLE_LINKER);
        });
        WormholeClientNetworking.register();
    }
}
