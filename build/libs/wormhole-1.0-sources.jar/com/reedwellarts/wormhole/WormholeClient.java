package com.reedwellarts.wormhole;

import com.reedwellarts.wormhole.client.WormholeChargerScreen;
import com.reedwellarts.wormhole.client.WormholeClientNetworking;
import com.reedwellarts.wormhole.registrar.ItemRegistrar;
import com.reedwellarts.wormhole.registrar.ScreenHandlerRegistrar;
import com.reedwellarts.wormhole.screen.WormholeChargerScreenHandler;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_3929;
import net.minecraft.class_7706;

public class WormholeClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> {
            entries.method_45421(ItemRegistrar.WORMHOLE_LINKER);
        });

        WormholeClientNetworking.register();

        class_3929.method_17542(
                ScreenHandlerRegistrar.WORMHOLE_CHARGER_HANDLER,
                WormholeChargerScreen::new
        );
    }
}
