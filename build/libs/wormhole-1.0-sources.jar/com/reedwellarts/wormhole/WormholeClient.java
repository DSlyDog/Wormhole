package com.reedwellarts.wormhole;

import com.reedwellarts.wormhole.client.TestScreen;
import com.reedwellarts.wormhole.client.WormholeClientNetworking;
import com.reedwellarts.wormhole.items.ItemRegistrar;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_7706;
import org.lwjgl.glfw.GLFW;

public class WormholeClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> {
            entries.method_45421(ItemRegistrar.WORMHOLE_LINKER);
        });
        WormholeClientNetworking.register();

        class_304 testKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.wormhole.test",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_K,
                class_304.class_11900.method_74698(class_2960.method_60655(Wormhole.MOD_ID, "keys"))
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (testKey.method_1436()) {
                client.method_1507(new TestScreen());
            }
        });
    }
}
