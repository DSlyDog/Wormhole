package com.reedwellarts.wormhole.client;

import net.minecraft.class_11909;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_350;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_6382;
import net.minecraft.class_7842;
import net.minecraft.client.gui.widget.*;
import java.util.List;

public class ControllerScreen extends class_437 {

    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_GAP = 4;

    private final class_2338 controllerPos;
    private final List<String> destinations;

    public ControllerScreen(class_2338 controllerPos, List<String> destinations){
        super(class_2561.method_43470("Select Destination"));
        this.controllerPos = controllerPos;
        this.destinations = destinations;
    }

    @Override
    protected void method_25426(){
        method_37063(new class_7842(
                field_22789 / 2 - (field_22793.method_30880(method_25440().method_30937()) / 2),
                10,
                field_22793.method_30880(method_25440().method_30937()),
                20,
                method_25440(),
                field_22793
        ));

        method_37063(new PortalListWidget());

        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), button -> method_25419())
                .method_46434(field_22789 / 2 - BUTTON_WIDTH / 4, field_22790 - 25, BUTTON_WIDTH / 2, BUTTON_HEIGHT)
                .method_46431());
    }

    @Override
    public boolean method_25421(){
        return false;
    }

    private class PortalListWidget extends class_350<PortalListWidget.PortalEntry> {

        public PortalListWidget(){
            super(
                    ControllerScreen.this.field_22787,
                    ControllerScreen.this.field_22789,
                    ControllerScreen.this.field_22790 - 60,
                    30,
                    BUTTON_HEIGHT + 4
            );

            for (String destination : destinations){
                method_25321(new PortalEntry(destination));
            }
        }

        @Override
        protected void method_47399(class_6382 builder) {

        }

        @Override
        protected void renderEntry(class_332 context, int mouseX, int mouseY, float delta, PortalEntry entry) {
            entry.button.method_46419(entry.getY());
            super.method_44397(context, mouseX, mouseY, delta, entry);
        }

        private class PortalEntry extends class_350.class_351<PortalEntry>{

            private final class_4185 button;

            public PortalEntry(String name){
                this.button = class_4185.method_46430(class_2561.method_43470(name), btn -> {
                    WormholeClientNetworking.sendSelectedDestination(controllerPos, name);
                    method_25419();
                }).method_46432(BUTTON_WIDTH).method_46431();
                button.method_46421(field_22758 / 2 - BUTTON_WIDTH / 2);
                button.method_46419(field_22759 / 2 - 40);
                button.method_46421(field_22758 / 2 - BUTTON_WIDTH / 2);
            }

            @Override
            public void setY(int y){
                super.setY(y);
                button.method_46419(y);
            }

            @Override
            public void render(class_332 context, int mouseX, int mouseY, boolean hovered, float deltaTicks) {
                button.method_25394(context, mouseX, mouseY, deltaTicks);
            }

            @Override
            public boolean mouseClicked(class_11909 click, boolean doubled) {
                return button.method_25402(click, doubled);
            }
        }
    }
}
