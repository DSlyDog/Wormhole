package com.reedwellarts.wormhole.client;

import com.reedwellarts.wormhole.Wormhole;
import com.reedwellarts.wormhole.WormholeClient;
import com.reedwellarts.wormhole.network.RegisterPortalNamePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_11908;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;

public class NamePortalScreen extends class_437 {

    private final class_2338 basePos;
    private class_342 nameField;
    private class_7842 textWidget;

    public NamePortalScreen(class_2338 basePos){
        super(class_2561.method_43470("Name this portal"));
        this.basePos = basePos;
    }

    @Override
    protected void method_25426() {
        textWidget = new class_7842(field_22789 / 2 - (field_22793.method_30880(method_25440().method_30937()) / 2), field_22790 / 2 - 60, field_22793.method_30880(method_25440().method_30937()), 20, method_25440(), field_22793);
        method_37063(textWidget);

        nameField = new class_342(field_22793, field_22789 / 2 - 100, field_22790 / 2 - 20, 200 , 20, class_2561.method_43470("Portal name"));
        nameField.method_1880(32);
        nameField.method_25365(true);
        method_37063(nameField);

        method_37063(class_4185.method_46430(class_2561.method_43470("Confirm"), button -> confirm())
                .method_46434(field_22789 / 2 - 102, field_22790 / 2 + 8, 98, 20)
                .method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), button -> method_25419())
                .method_46434(field_22789 / 2 + 4, field_22790 / 2 + 8, 98, 20)
                .method_46431());
    }

    @Override
    public boolean method_25404(class_11908 keyInput){
        if (keyInput.method_74228() == 257 || keyInput.method_74228() == 335){
            confirm();
            return true;
        }
        return super.method_25404(keyInput);
    }

    private void confirm(){
        String name = nameField.method_1882().trim();
        if (!name.isEmpty()) {
            WormholeClientNetworking.registerPortalName(basePos, name);
        }
        method_25419();
    }

    @Override
    public boolean method_25421(){
        return false;
    }
}
