package com.reedwellarts.wormhole.client;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class TestScreen extends class_437 {
    public TestScreen() {
        super(class_2561.method_43470("Test"));
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_25300(method_64506(), "TEST", field_22789 / 2, 128, 0xFFFFFF);
    }
}
