package com.reedwellarts.wormhole.client;

import com.reedwellarts.wormhole.screen.WormholeChargerScreenHandler;
import net.minecraft.class_10799;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;

public class WormholeChargerScreen extends class_465<WormholeChargerScreenHandler> {

    private static final class_2960 TEXTURE = class_2960.method_60655("wormhole", "textures/gui/wormhole_charger.png");

    public WormholeChargerScreen(WormholeChargerScreenHandler handler, class_1661 inventory, class_2561 title){
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.field_25269 = 8;
        this.field_25270 = this.field_2779 - 94;
        this.field_25267 = 8;
        this.field_25268 = 6;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        method_25420(context, mouseX, mouseY, deltaTicks);
        super.method_25394(context, mouseX, mouseY, deltaTicks);
        method_2380(context, mouseX, mouseY);
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY){
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;
        context.method_52706(class_10799.field_56883, TEXTURE, x, y, field_2792, field_2779);
    }
}
