package com.reedwellarts.wormhole.client;

import com.reedwellarts.wormhole.Wormhole;
import com.reedwellarts.wormhole.network.OpenControllerScreenPayload;
import com.reedwellarts.wormhole.network.OpenNameScreenPayload;
import com.reedwellarts.wormhole.network.RegisterPortalNamePayload;
import com.reedwellarts.wormhole.network.SelectDestinationPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;

public class WormholeClientNetworking {

    public static void register() {
        Wormhole.LOGGER.info("Registering wormhole client");

        ClientPlayNetworking.registerGlobalReceiver(OpenControllerScreenPayload.ID, (payload, context) ->

                context.client().execute(() ->
                        context.client().method_1507(
                                new ControllerScreen(payload.controllerPos(), payload.destinationNames())
                        )
                )
        );

        ClientPlayNetworking.registerGlobalReceiver(OpenNameScreenPayload.ID, (payload, context) ->
                context.client().execute(() ->
                        context.client().method_1507(new NamePortalScreen(payload.basePos()))
                ));
    }

    public static void sendSelectedDestination(class_2338 controllerPos, String destinationName){
        ClientPlayNetworking.send(new SelectDestinationPayload(controllerPos, destinationName));
    }

    public static void registerPortalName(class_2338 basePos, String name) {
        ClientPlayNetworking.send(new RegisterPortalNamePayload(basePos, name));
    }
}
