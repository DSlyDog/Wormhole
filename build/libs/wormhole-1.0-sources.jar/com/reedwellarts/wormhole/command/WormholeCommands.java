package com.reedwellarts.wormhole.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.reedwellarts.wormhole.util.WormholeLinkState;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import java.util.Map;

public class WormholeCommands {

    private WormholeCommands() {}

    public static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            register(dispatcher);
        });
    }

    private static void register(CommandDispatcher<class_2168> dispatcher){
        dispatcher.register(
                class_2170.method_9247("wormhole")
                        .then(class_2170.method_9247("list").executes(WormholeCommands::listPortals))
        );
    }

    private static int listPortals(CommandContext<class_2168> ctx){
        class_2168 source = ctx.getSource();
        class_3218 world = source.method_9225();
        WormholeLinkState state = WormholeLinkState.get(world);

        Map<String, class_2338> portals = state.allPortals();
        if (portals.isEmpty()){
            source.method_9226(() ->
                    class_2561.method_43470("No portals registered in this dimension")
                            .method_27692(class_124.field_1061),
                    false);
            return 0;
        }

        portals.forEach((name, pos) ->
                source.method_9226(() ->
                        class_2561.method_43470(" '" + name + "' → " + pos.method_23854())
                                .method_27692(class_124.field_1075),
                        false));

        source.method_9226(() ->
                class_2561.method_43470("Total: " + portals.size() + " portal(s)")
                        .method_27692(class_124.field_1054),
                false);
        return portals.size();
    }
}
