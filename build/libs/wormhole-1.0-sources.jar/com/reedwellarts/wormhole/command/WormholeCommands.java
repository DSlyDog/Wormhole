package com.reedwellarts.wormhole.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.reedwellarts.wormhole.components.ModComponents;
import com.reedwellarts.wormhole.items.BlockRegistrar;
import com.reedwellarts.wormhole.portal.WormholeLinkState;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.Map;

public class WormholeCommands {

    private WormholeCommands() {}

    public static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            register(dispatcher);
        });
    }

    private static void register(CommandDispatcher<class_2168> dispatcher){
        dispatcher.register(
                class_2170.method_9247("wormhole")
                        .then(class_2170.method_9247("list").executes(WormholeCommands::listPortals))
                        .then(class_2170.method_9247("name")
                                .then(class_2170.method_9244("name", StringArgumentType.word())
                                        .executes(WormholeCommands::namePortal)))
        );
    }

    private static int namePortal(CommandContext<class_2168> ctx){
        class_2168 source = ctx.getSource();
        class_3222 player = source.method_44023();
        if (player == null){
            source.method_9226(() ->
                    class_2561.method_43470("This command can only be used by players").method_27692(class_124.field_1061), false);
            return 0;
        }

        class_1799 held = player.method_6047();
        class_2338 pending = held.method_58694(ModComponents.PENDING_PORTAL_PS);
        if (pending == null){
            source.method_9226(() ->
                    class_2561.method_43470("No portal base selected. Right-click a portal base with the Wormhole Linker first.")
                            .method_27692(class_124.field_1061),
                    false);
            return 0;
        }

        String name = StringArgumentType.getString(ctx, "name");
        class_3218 world = source.method_9225();

        if (!world.method_8320(pending).method_27852(BlockRegistrar.WORMHOLE_PORTAL_BASE)){
            source.method_9226(() ->
                    class_2561.method_43470("The selected block is no longer a portal base")
                            .method_27692(class_124.field_1061),
                    false);
            held.method_57381(ModComponents.PENDING_PORTAL_PS);
            return 0;
        }

        WormholeLinkState.get(world).registerPortal(name, pending);
        held.method_57381(ModComponents.PENDING_PORTAL_PS);

        source.method_9226(() ->
                class_2561.method_43470("Portal registered as '" + name + "' at " + pending.method_23854())
                        .method_27692(class_124.field_1060),
                false);
        return 1;
    }

    private static int listPortals(CommandContext<class_2168> ctx){
        class_2168 source = ctx.getSource();
        class_3218 world = source.method_9225();
        WormholeLinkState state = WormholeLinkState.get(world);

        Map<String, class_2338> portals = state.allPortals();
        if (portals.isEmpty()){
            source.method_9226(() ->
                    class_2561.method_43470("No portals registered in this dimension")
                            .method_27692(class_124.field_1061),
                    false);
            return 0;
        }

        portals.forEach((name, pos) ->
                source.method_9226(() ->
                        class_2561.method_43470(" '" + name + "' → " + pos.method_23854())
                                .method_27692(class_124.field_1075),
                        false));

        source.method_9226(() ->
                class_2561.method_43470("Total: " + portals.size() + " portal(s)")
                        .method_27692(class_124.field_1054),
                false);
        return portals.size();
    }
}
