package com.reedwellarts.wormhole.components;

import com.reedwellarts.wormhole.Wormhole;
import java.util.function.UnaryOperator;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9331;

public class ModComponents {

    public static final class_9331<class_2338> PENDING_PORTAL_PS = register(
            "pending_portal_ps",
            builder -> builder
                    .method_57881(class_2338.field_25064)
                    .method_57882(class_2338.field_48404)
    );

    private static <T> class_9331<T> register(String name, UnaryOperator<class_9331.class_9332<T>> builderOp){
        class_2960 id = class_2960.method_60655(Wormhole.MOD_ID, name);
        class_9331<T> type = builderOp.apply(class_9331.<T>method_57873()).method_57880();
        return class_2378.method_10230(class_7923.field_49658, id, type);
    }

    public static void registerModComponents() {
        Wormhole.LOGGER.info("Registering data components for {}", Wormhole.MOD_ID);
    }
}
