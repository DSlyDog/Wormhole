package com.reedwellarts.wormhole.items.blocks.BlockEntity;

import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3858;
import net.minecraft.class_3908;
import net.minecraft.class_3913;
import org.jspecify.annotations.Nullable;

public class WormholeChargerBlockEntity extends class_2586 implements class_3908 {

    private final class_2371<class_1799> items = class_2371.method_10213(3, class_1799.field_8037);

    private final class_3913 properties = new class_3913() {
        private final int[] data = new int[4];

        @Override
        public int method_17390(int index) {
            return data[index];
        }

        @Override
        public void method_17391(int index, int value) {
            data[index] = value;
        }

        @Override
        public int method_17389() {
            return data.length;
        }
    };

    public WormholeChargerBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43470("Handheld Portal Charger");
    }

    @Override
    public @Nullable class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        class_1277 inv = new class_1277(3) {

            @Override
            public class_1799 method_5438(int slot){
                return items.get(slot);
            }

            @Override
            public void method_5447(int slot, class_1799 stack){
                items.set(slot, stack);
                method_5431();
            }
        };

        return new class_3858(syncId, playerInventory, inv, properties);
    }

    @Override
    protected void method_11007(class_11372 view) {
        super.method_11007(view);

        class_1262.method_5426(view, items);
        view.method_71465("LitTime", properties.method_17390(0));
        view.method_71465("LitDuration", properties.method_17390(1));
        view.method_71465("CookTime", properties.method_17390(2));
        view.method_71465("CookTimeTotal", properties.method_17390(3));
    }

    @Override
    protected void method_11014(class_11368 view) {
        super.method_11014(view);

        class_1262.method_5429(view, items);
        properties.method_17391(0, view.method_71424("LitTime", 0));
        properties.method_17391(1, view.method_71424("LitDuration", 0));
        properties.method_17391(2, view.method_71424("CookTime", 0));
        properties.method_17391(3, view.method_71424("CookTimeTotal", 200));
    }
}
