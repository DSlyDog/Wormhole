package com.reedwellarts.wormhole.items.blocks.BlockEntity;

import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;

public class WormholeControllerBlockEntity extends class_2586 {

    private class_2338 linkedBase = null;

    public WormholeControllerBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state){
        super(type, pos, state);
    }

    public class_2338 getLinkedBase(){
        return linkedBase;
    }

    public void setLinkedBase(class_2338 pos){
        this.linkedBase = pos == null? null : pos.method_10062();
        method_5431();
    }

    @Override
    protected void method_11007(class_11372 view) {
        super.method_11007(view);
        if (linkedBase != null){
            view.method_71466("LinkedBase", linkedBase.method_10063());
        }
    }

    @Override
    protected void method_11014(class_11368 view) {
        super.method_11014(view);
        if (view.contains("LinkedBase")){
            linkedBase = class_2338.method_10092(view.method_71425("LinkedBase", 0));
        }
    }
}
