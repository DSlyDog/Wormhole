package com.reedwellarts.wormhole.items.blocks;

import com.mojang.serialization.MapCodec;
import com.reedwellarts.wormhole.registrar.BlockRegistrar;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3965;
import com.reedwellarts.wormhole.items.blocks.BlockEntity.WormholeChargerBlockEntity;
import org.jspecify.annotations.Nullable;

public class WormholeChargerBlock extends class_2248 implements class_2343 {

    private static final MapCodec<WormholeChargerBlock> CODEC =
            method_54094(WormholeChargerBlock::new);

    public WormholeChargerBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(class_2741.field_12525, class_2350.field_11043));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(class_2741.field_12525);
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 ctx) {
        return method_9564().method_11657(class_2741.field_12525, ctx.method_8042().method_10153());
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return field_46280;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new WormholeChargerBlockEntity(BlockRegistrar.WORMHOLE_CHARGER_BLOCK_ENTITY, pos, state);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (world.method_8608()) return class_1269.field_5812;

        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof WormholeChargerBlockEntity charger){
            player.method_17355(charger);
            return class_1269.field_21466;
        }
        return class_1269.field_5811;
    }
}
