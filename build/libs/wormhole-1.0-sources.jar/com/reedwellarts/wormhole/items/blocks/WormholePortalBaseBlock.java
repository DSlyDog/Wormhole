package com.reedwellarts.wormhole.items.blocks;

import com.reedwellarts.wormhole.Wormhole;
import com.reedwellarts.wormhole.registrar.ItemRegistrar;
import com.reedwellarts.wormhole.network.OpenNameScreenPayload;
import com.reedwellarts.wormhole.network.WormholeServerNetworking;
import com.reedwellarts.wormhole.util.WormholeLinkState;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import java.util.Map;

public class WormholePortalBaseBlock extends class_2248 {

    public WormholePortalBaseBlock(class_2251 settings){
        super(settings);
        method_9590(method_9595().method_11664().method_11657(class_2741.field_12525, class_2350.field_11043));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder){
        builder.method_11667(class_2741.field_12525);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx){
        return method_9564().method_11657(class_2741.field_12525, ctx.method_8042().method_10153());
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit){
        if (!player.method_6047().method_31574(ItemRegistrar.WORMHOLE_LINKER)){
            return class_1269.field_5811;
        }

        if (world.method_8608()){
            return class_1269.field_5812;
        }

        class_3218 serverWorld = (class_3218) world;
        WormholeLinkState linkState = WormholeLinkState.get(serverWorld);

        boolean alreadyRegistered = linkState.allPortals().containsValue(pos.method_10062());
        if (alreadyRegistered){
            player.method_7353(
                    class_2561.method_43470("This portal base is already registered")
                            .method_27692(class_124.field_1061),
                    false
            );
            return class_1269.field_5814;
        }

        ServerPlayNetworking.send((class_3222) player, new OpenNameScreenPayload(pos));
        return class_1269.field_5812;
    }

    @Override
    protected void method_66388(class_2680 state, class_3218 world, class_2338 pos, boolean moved) {
        if (!world.method_8320(pos).method_27852(state.method_26204())){
            WormholeLinkState linkState = WormholeLinkState.get(world);

            if (pos != null) {
                WormholeLinkState.removePortalAbove(world, pos);
                for (Map.Entry<String, class_2338> link : linkState.allPortals().entrySet()) {
                    Wormhole.LOGGER.info("link value: {}, base value {}", link.getValue().toString(), pos.toString());
                    if (link.getValue().equals(pos)) {
                        linkState.unregisterPortal(link.getKey());
                        WormholeServerNetworking.sendSyncPortalNamesPayload(world);
                        break;
                    }
                }
            }
        }

        super.method_66388(state, world, pos, moved);
    }
}
