package com.reedwellarts.wormhole.items.blocks;

import com.mojang.serialization.MapCodec;
import com.reedwellarts.wormhole.Wormhole;
import com.reedwellarts.wormhole.items.BlockRegistrar;
import com.reedwellarts.wormhole.portal.WormholeLinkState;
import java.util.*;
import net.minecraft.class_10774;
import net.minecraft.class_1297;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3726;

public class WormholePortalBlock extends class_2248 {

    public static final MapCodec<WormholePortalBlock> CODEC = method_54094(WormholePortalBlock::new);
    private static final class_265 SHAPE_NS = class_2248.method_9541(0, 0, 7, 16, 16, 9);
    private static final class_265 SHAPE_EW = class_2248.method_9541(7, 0, 0, 9, 16, 16);

    public WormholePortalBlock(class_2251 settings){
        super(settings);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder){
        builder.method_11667(class_2741.field_12481);
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969(){
        return field_46280;
    }

    @Override
    public class_2680 method_9605(class_1750 ctx){
        return method_9564().method_11657(class_2741.field_12481, ctx.method_8042().method_10153());
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 ctx){
        if (!state.method_28498(class_2741.field_12481)){
            return SHAPE_NS;
        }

        class_2350 facing = state.method_11654(class_2741.field_12481);
        return (facing == class_2350.field_11034 || facing == class_2350.field_11039) ? SHAPE_EW : SHAPE_NS;
    }

    @Override
    protected class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context){
        return class_259.method_1073();
    }

    @Override
    public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity, class_10774 handler, boolean bl){
        if (world.method_8608()){
            return;
        }
        if (entity.method_51848() > 0) {
            entity.method_30229();
            return;
        }
        if (entity.method_5765() || entity.method_5782()){
            return;
        }

        class_3218 serverWorld = (class_3218) world;

        class_2350 facing = state.method_28498(class_2741.field_12481)
                ? state.method_11654(class_2741.field_12481)
                : class_2350.field_11043;
        boolean alongX = (facing == class_2350.field_11043 || facing == class_2350.field_11035);

        class_2338 basePos = findBase(serverWorld, pos, alongX);
        if (basePos == null){
            return;
        }

        WormholeLinkState linkState = WormholeLinkState.get(serverWorld);
        Optional<class_2338> destOpt = linkState.consumeDestination(basePos);
        if (destOpt.isEmpty()){
            return;
        }

        teleportToBase(serverWorld, entity, destOpt.get());
        entity.method_51850(class_1297.field_29988);

        WormholeLinkState.removePortalAbove(serverWorld, basePos);
    }

    private static void teleportToBase(class_3218 world, class_1297 entity, class_2338 destBase){
        class_2680 destState = world.method_8320(destBase);
        class_2350 facing = destState.method_28498(class_2741.field_12525)
                ? destState.method_11654(class_2741.field_12525)
                : class_2350.field_11043;

        class_2338 exitPos;
        if (world.method_8320(destBase.method_10093(facing)).method_26215()) {
            exitPos = destBase.method_10093(facing);
        }else{
            exitPos = destBase.method_10093(facing).method_10084();
        }

        class_243 center = class_243.method_24955(exitPos);

        float yaw = yawFromDirection(facing);
        entity.method_48105(world, center.field_1352, center.field_1351, center.field_1350, Set.of(), yaw, entity.method_36455(), false);
    }

    private static class_2338 findBase(class_3218 world, class_2338 start, boolean alongX){
        Set<class_2338> visited = new HashSet<>();
        Queue<class_2338> queue = new ArrayDeque<>();
        queue.add(start.method_10062());

        while(!queue.isEmpty()){
            class_2338 current = queue.poll();
            if (!visited.add(current)) continue;

            for (class_2338 neighbor : WormholeLinkState.planeNeighbors(current, alongX, true)){
                class_2680 neighborState = world.method_8320(neighbor);
                if (neighborState.method_27852(BlockRegistrar.WORMHOLE_PORTAL_BASE)){
                    return neighbor;
                }
                if (neighborState.method_27852(BlockRegistrar.WORMHOLE_PORTAL) && !visited.contains(neighbor)){
                    queue.add(neighbor.method_10062());
                }
            }
        }
        return null;
    }

    private static float yawFromDirection(class_2350 direction) {
        return switch (direction) {
            case field_11039  -> 90.0f;
            case field_11043 -> 180.0f;
            case field_11034  -> 270.0f;
            default    -> 0.0f;
        };
    }
}
