package com.reedwellarts.wormhole.items.blocks;

import com.reedwellarts.wormhole.registrar.BlockRegistrar;
import com.reedwellarts.wormhole.items.blocks.BlockEntity.WormholeControllerBlockEntity;
import com.reedwellarts.wormhole.network.OpenControllerScreenPayload;
import com.reedwellarts.wormhole.util.WormholeLinkState;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class WormholePortalControllerBlock extends class_2248 implements class_2343 {

    public WormholePortalControllerBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(class_2741.field_12525, class_2350.field_11043));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder){
        builder.method_11667(class_2741.field_12525);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx){
        return method_9564().method_11657(class_2741.field_12525, ctx.method_8042().method_10153());
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state){
        return new WormholeControllerBlockEntity(BlockRegistrar.CONTROLLER_BLOCK_ENTITY, pos, state);
    }

    @Override
    protected class_2464 method_9604(class_2680 state){
        return class_2464.field_11458;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit){
        if (world.method_8608()){
            return class_1269.field_5812;
        }

        class_3218 serverWorld = (class_3218) world;
        class_2586 blockEntity = world.method_8321(pos);
        if (!(blockEntity instanceof WormholeControllerBlockEntity controllerBE)){
            return class_1269.field_5811;
        }

        if (controllerBE.getLinkedBase() == null){
            class_2338 base = findNearbyBase(serverWorld, pos);
            if (base == null){
                player.method_7353(
                        class_2561.method_43470("No portal base found within 5 blocks")
                                .method_27692(class_124.field_1061),
                        false
                );
                return class_1269.field_5814;
            }
            controllerBE.setLinkedBase(base);
        }

        WormholeLinkState linkState = WormholeLinkState.get(serverWorld);
        Map<String, class_2338> all = linkState.allPortals();
        class_2338 linkedBase = controllerBE.getLinkedBase();

        List<String> destinations = new ArrayList<>();
        for (Map.Entry<String, class_2338> entry : all.entrySet()){
            if (!entry.getValue().equals(linkedBase)){
                destinations.add(entry.getKey());
            }
        }
        destinations.sort(String::compareTo);

        if (destinations.isEmpty()){
            player.method_7353(
                    class_2561.method_43470("No other portals are registered yet. Use the Wormhole Linker to add more")
                            .method_27692(class_124.field_1061),
                    false
            );
        }

        ServerPlayNetworking.send(
                (class_3222) player,
                new OpenControllerScreenPayload(pos, destinations)
        );
        return class_1269.field_5812;
    }

    private static class_2338 findNearbyBase(class_3218 world, class_2338 controllerPos){
        for (class_2338 candidate : class_2338.method_25996(controllerPos, 5, 5, 5)){
            if (world.method_8320(candidate).method_27852(BlockRegistrar.WORMHOLE_PORTAL_BASE)){
                return candidate.method_10062();
            }
        }
        return null;
    }
}
