package com.reedwellarts.wormhole.items.blocks;

import net.minecraft.class_2248;

public class WormholePortalFrameBlock extends class_2248 {

    public WormholePortalFrameBlock(class_2251 settings){
        super(settings);
    }
}
