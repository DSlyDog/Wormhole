package com.reedwellarts.wormhole.items.blocks;

import com.reedwellarts.wormhole.portal.WormholeLinkState;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;

public class WormholePortalFrameBlock extends class_2248 {

    public WormholePortalFrameBlock(class_2251 settings){
        super(settings);
    }


    @Override
    protected void method_66388(class_2680 state, class_3218 world, class_2338 pos, boolean moved) {
        if (!world.method_8320(pos).method_27852(state.method_26204())){
            class_2350 facing = state.method_28498(class_2741.field_12481)
                    ? state.method_11654(class_2741.field_12481)
                    : class_2350.field_11043;
            boolean alongX = (facing == class_2350.field_11043 || facing == class_2350.field_11035);
            class_2338 base = WormholeLinkState.findBase(world, pos, alongX);
            if (base != null) WormholeLinkState.removePortalAbove(world, base);
        }
    }

}
