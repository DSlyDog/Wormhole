package com.reedwellarts.wormhole.items.item;

import net.minecraft.class_1792;

public class HandheldPortalBattery extends class_1792 {
    public HandheldPortalBattery(class_1793 settings) {
        super(settings);
    }
}
