package com.reedwellarts.wormhole.items.item;

import com.reedwellarts.wormhole.network.OpenRemoteScreenPayload;
import com.reedwellarts.wormhole.util.WormholeLinkState;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class HandheldPortalItem extends class_1792 {

    public HandheldPortalItem(class_1793 settings) {
        super(settings);
    }



    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (world.method_8608()){
            return class_1269.field_5812;
        }

        class_1799 stack = user.method_6047();
        if (stack.method_7919() >= stack.method_7936()){
            return class_1269.field_5814;
        }

        class_3218 serverWorld = (class_3218) world;
        WormholeLinkState linkState = WormholeLinkState.get(serverWorld);

        List<String> destinations = new ArrayList<>();

        for (Map.Entry<String, class_2338> entry : linkState.allPortals().entrySet()){
            destinations.add(entry.getKey());
        }

        if (destinations.isEmpty()){
            user.method_7353(class_2561.method_43470("No portals are registered yet. Use a linker to add some")
                    .method_27692(class_124.field_1061),
                    false);
            return class_1269.field_5814;
        }

        ServerPlayNetworking.send(
                (class_3222) user,
                new OpenRemoteScreenPayload(destinations)
        );

        return class_1269.field_5812;
    }
}
