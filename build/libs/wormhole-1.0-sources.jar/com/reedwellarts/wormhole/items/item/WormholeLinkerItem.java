package com.reedwellarts.wormhole.items.item;

import com.reedwellarts.wormhole.components.ModComponents;
import com.reedwellarts.wormhole.items.BlockRegistrar;
import com.reedwellarts.wormhole.portal.WormholeLinkState;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

public class WormholeLinkerItem extends class_1792 {

    public WormholeLinkerItem(class_1793 settings){
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context){
        class_1937 world = context.method_8045();
        class_1657 player = context.method_8036();
        class_2338 clickedPos = context.method_8037();

        if (player == null) {
            return class_1269.field_5811;
        }

        if (!world.method_8320(clickedPos).method_27852(BlockRegistrar.WORMHOLE_PORTAL_BASE)){
            return class_1269.field_5811;
        }

        if (world.method_8608()) {
            return class_1269.field_5812;
        }

        context.method_8041().method_57379(ModComponents.PENDING_PORTAL_PS, clickedPos.method_10062());

        return class_1269.field_5812;
    }
}
