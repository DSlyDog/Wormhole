package com.reedwellarts.wormhole.network;

import com.reedwellarts.wormhole.Wormhole;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record OpenControllerScreenPayload(class_2338 controllerPos, List<String> destinationNames)
    implements class_8710 {

    public static final class_9154<OpenControllerScreenPayload> ID =
            new class_9154<>(class_2960.method_60655(Wormhole.MOD_ID, "open_controller_screen"));

    public static final class_9139<class_9129, OpenControllerScreenPayload> CODEC =
            class_9139.method_56435(
                    class_2338.field_48404, OpenControllerScreenPayload::controllerPos,
                    class_9135.field_48554.method_56433(class_9135.method_56363()), OpenControllerScreenPayload::destinationNames,
                    OpenControllerScreenPayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
