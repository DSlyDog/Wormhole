package com.reedwellarts.wormhole.network;

import com.reedwellarts.wormhole.Wormhole;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record RegisterPortalNamePayload(class_2338 basePos, String name) implements class_8710 {

    public static final class_9154<RegisterPortalNamePayload> ID =
            new class_9154<>(class_2960.method_60655(Wormhole.MOD_ID, "register_portal_name"));

    public static final class_9139<class_9129, RegisterPortalNamePayload> CODEC =
            class_9139.method_56435(
                    class_2338.field_48404, RegisterPortalNamePayload::basePos,
                    class_9135.field_48554, RegisterPortalNamePayload::name,
                    RegisterPortalNamePayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479(){
        return ID;
    }
}
