package com.reedwellarts.wormhole.network;

import com.reedwellarts.wormhole.Wormhole;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SelectDestinationPayload(class_2338 controllerPos, String destinationName)
    implements class_8710 {

    public static final class_9154<SelectDestinationPayload> ID =
            new class_9154<>(class_2960.method_60655(Wormhole.MOD_ID, "select_destination"));

    public static final class_9139<class_9129, SelectDestinationPayload> CODEC =
            class_9139.method_56435(
                    class_2338.field_48404, SelectDestinationPayload::controllerPos,
                    class_9135.field_48554, SelectDestinationPayload::destinationName,
                    SelectDestinationPayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479(){
        return ID;
    }
}
