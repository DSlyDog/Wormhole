package com.reedwellarts.wormhole.network;

import com.reedwellarts.wormhole.Wormhole;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SelectDestinationRemotePayload(String destinationName) implements class_8710 {

    public static final class_9154<SelectDestinationRemotePayload> ID =
            new class_9154<>(class_2960.method_60655(Wormhole.MOD_ID, "select_destination_remote"));

    public static final class_9139<class_9129, SelectDestinationRemotePayload> CODEC =
            class_9139.method_56434(
                    class_9135.field_48554, SelectDestinationRemotePayload::destinationName,
                    SelectDestinationRemotePayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
