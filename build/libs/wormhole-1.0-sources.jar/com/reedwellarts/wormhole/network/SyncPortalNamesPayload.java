package com.reedwellarts.wormhole.network;

import com.reedwellarts.wormhole.Wormhole;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SyncPortalNamesPayload(List<String> names) implements class_8710 {

    public static final class_9154<SyncPortalNamesPayload> ID = new class_9154<>(class_2960.method_60655(Wormhole.MOD_ID, "sync_portal_names"));

    public static final class_9139<class_9129, SyncPortalNamesPayload> CODEC = class_9139.method_56434(
            class_9135.field_48554.method_56433(class_9135.method_56363()), SyncPortalNamesPayload::names,
            SyncPortalNamesPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479(){
        return ID;
    }
}
