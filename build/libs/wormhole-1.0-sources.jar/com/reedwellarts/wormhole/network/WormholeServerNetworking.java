package com.reedwellarts.wormhole.network;

import com.reedwellarts.wormhole.items.blocks.WormholeControllerBlockEntity;
import com.reedwellarts.wormhole.portal.WormholeLinkState;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.List;
import java.util.Optional;

public class WormholeServerNetworking {

    public static void register(){
        PayloadTypeRegistry.playS2C().register(OpenControllerScreenPayload.ID, OpenControllerScreenPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(OpenNameScreenPayload.ID, OpenNameScreenPayload.CODEC);

        PayloadTypeRegistry.playC2S().register(SelectDestinationPayload.ID, SelectDestinationPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(RegisterPortalNamePayload.ID, RegisterPortalNamePayload.CODEC);

        PayloadTypeRegistry.playS2C().register(SyncPortalNamesPayload.ID, SyncPortalNamesPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(SelectDestinationPayload.ID, (payload, context) -> {
            class_3222 player = context.player();
            class_3218 world = player.method_51469().method_8410();

            class_2586 blockEntity = world.method_8321(payload.controllerPos());
            if (!(blockEntity instanceof WormholeControllerBlockEntity controllerBE)) {
                return;
            }

            class_2338 sourceBase = controllerBE.getLinkedBase();
            if (sourceBase == null){
                return;
            }

            WormholeLinkState linkState = WormholeLinkState.get(world);
            Optional<class_2338> destBaseOpt = linkState.getPortalPos(payload.destinationName());
            if (destBaseOpt.isEmpty()){
                player.method_7353(
                        class_2561.method_43470("Portal '" + payload.destinationName() + "' no longer exists")
                                .method_27692(class_124.field_1061),
                        false
                );
                return;
            }

            class_2338 destBase = destBaseOpt.get();
            boolean opened = linkState.activatePortal(world, sourceBase, destBase);
            if (!opened){
                player.method_7353(
                        class_2561.method_43470("Could not open portal. Is the frame intact?")
                                .method_27692(class_124.field_1061),
                        false
                );
                return;
            }

            player.method_7353(
                    class_2561.method_43470("Portal opened → " + payload.destinationName())
                            .method_27692(class_124.field_1060),
                    false
            );
        });

        ServerPlayNetworking.registerGlobalReceiver(RegisterPortalNamePayload.ID, (payload, context) -> {
            String name = payload.name().trim();
            if (name.isEmpty()){
                return;
            }
            class_3218 world = context.player().method_51469().method_8410();
            WormholeLinkState state = WormholeLinkState.get(world);
            state.registerPortal(name, payload.basePos());

            sendSyncPortalNamesPayload(world);

            context.player().method_7353(
                    class_2561.method_43470("Portal registered as '" + name + "'").method_27692(class_124.field_1060),
                    false
            );
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3218 world = handler.method_32311().method_51469().method_8410();
            WormholeLinkState state = WormholeLinkState.get(world);
            SyncPortalNamesPayload payload = new SyncPortalNamesPayload(
                    List.copyOf(state.allPortals().keySet())
            );

            sender.sendPacket(payload);
        });
    }

    public static void sendSyncPortalNamesPayload(class_3218 world){
        SyncPortalNamesPayload syncPayload = new SyncPortalNamesPayload(
                List.copyOf(WormholeLinkState.get(world).allPortals().keySet())
        );

        for (class_3222 player : world.method_18456()) {
            ServerPlayNetworking.send(player, syncPayload);
        }
    }
}
