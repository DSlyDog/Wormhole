package com.reedwellarts.wormhole.portal;

import com.jcraft.jorbis.Block;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.reedwellarts.wormhole.Wormhole;
import com.reedwellarts.wormhole.items.BlockRegistrar;
import java.util.*;
import net.minecraft.class_10741;
import net.minecraft.class_18;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_26;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;

public class WormholeLinkState extends class_18 {

    private static final String SAVE_ID = Wormhole.MOD_ID + "_links";

    private static final Codec<WormholeLinkState> CODEC = RecordCodecBuilder.create(
            instance -> instance.group(
                    Codec.unboundedMap(Codec.STRING, class_2338.field_25064)
                            .fieldOf("portals")
                            .forGetter(s -> Map.copyOf(s.namedPortals))
            ).apply(instance, WormholeLinkState::new)
    );

    public static final class_10741<WormholeLinkState> TYPE = new class_10741<>(
            SAVE_ID,
            WormholeLinkState::new,
            CODEC,
            null
    );

    private final Map<String, class_2338> namedPortals = new HashMap<>();
    private final Map<class_2338, class_2338> oneShotDestinations = new HashMap<>();

    public WormholeLinkState(){}

    private WormholeLinkState(Map<String, class_2338> initial){
        this.namedPortals.putAll(initial);
    }

    public static WormholeLinkState get(class_3218 world) {
        class_26 manager = world.method_17983();
        return manager.method_17924(TYPE);
    }

    public void registerPortal(String name, class_2338 base){
        namedPortals.put(name, base.method_10062());
        method_80();
    }

    public void unregisterPortal(String name){
        if (namedPortals.remove(name) != null) method_80();
    }

    public Optional<class_2338> getPortalPos(String name){
        return Optional.ofNullable(namedPortals.get(name));
    }

    public Map<String, class_2338> allPortals() {
        return Collections.unmodifiableMap(namedPortals);
    }

    public boolean activatePortal(class_3218 world, class_2338 sourceBase, class_2338 destBase){
        if (!tryPlacePortalAbove(world, sourceBase)){
            return false;
        }

        oneShotDestinations.put(sourceBase.method_10062(), destBase.method_10062());
        return true;
    }

    public Optional<class_2338> consumeDestination(class_2338 sourceBase){
        return Optional.ofNullable(oneShotDestinations.remove(sourceBase.method_10062()));
    }

    public boolean hasActiveDestination(class_2338 sourceBase){
        return oneShotDestinations.containsKey(sourceBase);
    }

    public static boolean tryPlacePortalAbove(class_3218 world, class_2338 base){
        class_2680 baseState = world.method_8320(base);
        if (!baseState.method_27852(BlockRegistrar.WORMHOLE_PORTAL_BASE)){
            return false;
        }

        class_2350 facing = baseState.method_28498(class_2741.field_12525)
                ? baseState.method_11654(class_2741.field_12525)
                : class_2350.field_11043;

        boolean alongX = (facing == class_2350.field_11043 || facing == class_2350.field_11035);

        class_2338 seed = base.method_10084();
        class_2680 seedState = world.method_8320(seed);
        if (!seedState.method_26215() && !seedState.method_45474()){
            return false;
        }

        Set<class_2338> interior = new HashSet<>();
        Queue<class_2338> queue = new ArrayDeque<>();
        queue.add(seed.method_10062());
        interior.add(seed.method_10062());

        while(!queue.isEmpty()){
            if (interior.size() > 256){
                return false;
            }

            class_2338 current = queue.poll();
            for (class_2338 neighbor : planeNeighbors(current, alongX, false)){
                if (interior.contains(neighbor)){
                    continue;
                }

                class_2680 neighborState = world.method_8320(neighbor);
                if (isFrameBlock(neighborState)){
                    continue;
                }else if (neighborState.method_26215() || neighborState.method_45474()){
                    interior.add(neighbor.method_10062());
                    queue.add(neighbor.method_10062());
                }else{
                    Wormhole.LOGGER.info("Not frame or mutable: {}", neighborState);
                    Wormhole.LOGGER.info("Immutable pos: {}", neighbor.toString());
                    return false;
                }
            }
        }

        for (class_2338 pos : interior){
            for (class_2338 neighbor : planeNeighbors(pos, alongX, false)){
                if (interior.contains(neighbor)){
                    continue;
                }
                if (!isFrameBlock(world.method_8320(neighbor))){
                    return false;
                }
            }
        }

        class_2680 portalState = BlockRegistrar.WORMHOLE_PORTAL.method_9564()
                .method_11657(class_2741.field_12481, facing);
        for (class_2338 pos : interior){
            world.method_8501(pos.method_10062(), portalState);
        }

        return true;
    }

    private static boolean isFrameBlock(class_2680 blockState) {
        return blockState.method_27852(BlockRegistrar.WORMHOLE_PORTAL_FRAME)
                || blockState.method_27852(BlockRegistrar.WORMHOLE_PORTAL_BASE);
    }

    public static List<class_2338> planeNeighbors(class_2338 pos, boolean alongX, boolean includeDown){
        if (alongX){
            List<class_2338> positions = new ArrayList<>(List.of(pos.method_10078(), pos.method_10067(), pos.method_10084()));
            if (includeDown) positions.add(pos.method_10074());
            return positions;
        }else{
            List<class_2338> positions = new ArrayList<>(List.of(pos.method_10095(), pos.method_10072(), pos.method_10084()));
            if (includeDown) positions.add(pos.method_10074());
            return positions;
        }
    }

    public static void removePortalAbove(class_3218 world, class_2338 base){
        class_2680 baseState = world.method_8320(base);
        class_2350 facing = baseState.method_28498(class_2741.field_12525)
                ? baseState.method_11654(class_2741.field_12525)
                : class_2350.field_11043;
        boolean alongX = (facing == class_2350.field_11043 || facing == class_2350.field_11035);

        class_2338 seed = base.method_10084();
        if (!world.method_8320(seed).method_27852(BlockRegistrar.WORMHOLE_PORTAL)){
            return;
        }

        Set<class_2338> visited = new HashSet<>();
        Queue<class_2338> queue = new ArrayDeque<>();
        queue.add(seed.method_10062());

        while(!queue.isEmpty()){
            class_2338 current = queue.poll();
            if (!visited.add(current)){
                continue;
            }

            if (world.method_8320(current).method_27852(BlockRegistrar.WORMHOLE_PORTAL)){
                world.method_8650(current, false);
                for (class_2338 neighbor : planeNeighbors(current, alongX, false)) {
                    if (!visited.contains(neighbor)){
                        queue.add(neighbor.method_10062());
                    }
                }
            }
        }
    }
}
