package com.reedwellarts.wormhole.registrar;

import com.reedwellarts.wormhole.Wormhole;
import com.reedwellarts.wormhole.items.blocks.*;
import com.reedwellarts.wormhole.items.blocks.BlockEntity.WormholeChargerBlockEntity;
import com.reedwellarts.wormhole.items.blocks.BlockEntity.WormholeControllerBlockEntity;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.function.Function;

public class BlockRegistrar {

    public static final class_2248 WORMHOLE_PORTAL_BASE = register(
            "wormhole_portal_base",
            WormholePortalBaseBlock::new,
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16014)
                    .method_9629(3.0f, 6.0f)
                    .method_9626(class_2498.field_55794),
            true
    );

    public static final class_2248 WORMHOLE_PORTAL_FRAME = register(
            "wormhole_portal_frame",
            WormholePortalFrameBlock::new,
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16014)
                    .method_9629(3.0f, 6.0f)
                    .method_9626(class_2498.field_55794),
            true
    );

    public static final class_2248 WORMHOLE_PORTAL = register(
            "wormhole_portal",
            WormholePortalBlock::new,
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16014)
                    .method_9634()
                    .method_22488()
                    .method_9629(-1.0f, 3600000.0f)
                    .method_9631(state -> 11)
                    .method_9626(class_2498.field_11537)
                    .method_42327(),
            false
    );

    public static final class_2248 WORMHOLE_PORTAL_CONTROLLER = register(
            "wormhole_portal_controller",
            WormholePortalControllerBlock::new,
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16014)
                    .method_9629(3.0f, 6.0f)
                    .method_9626(class_2498.field_55794),
            true
    );

    public static final class_2248 WORMHOLE_PORTAL_CHARGER = register(
            "wormhole_portal_charger",
            WormholeChargerBlock::new,
            class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16014)
                    .method_9629(3.0f, 6.0f)
                    .method_9626(class_2498.field_55794),
            true
    );

    public static class_2591<WormholeControllerBlockEntity> CONTROLLER_BLOCK_ENTITY;
    public static class_2591<WormholeChargerBlockEntity> WORMHOLE_CHARGER_BLOCK_ENTITY;

    private static class_2248 register(String name,
                                  Function<class_4970.class_2251, class_2248> factory,
                                  class_4970.class_2251 settings,
                                  boolean shouldRegisterItem) {
        class_2960 id = class_2960.method_60655(Wormhole.MOD_ID, name);
        class_5321<class_2248> blockKey = class_5321.method_29179(class_7924.field_41254, id);

        class_2248 block = factory.apply(settings.method_63500(blockKey));
        class_2378.method_39197(class_7923.field_41175, blockKey, block);

        if (shouldRegisterItem) {
            class_5321<class_1792> itemKey = class_5321.method_29179(class_7924.field_41197, id);
            class_1747 blockItem = new class_1747(block, new class_1792.class_1793().method_63686(itemKey).method_63685());
            class_2378.method_39197(class_7923.field_41178, itemKey, blockItem);
        }

        return block;
    }

    public static void registerModBlocks() {
        Wormhole.LOGGER.info( "Registering blocks for {}", Wormhole.MOD_ID);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(entries ->
            entries.method_45421(WORMHOLE_PORTAL_BASE)
        );

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(entries ->
            entries.method_45421(WORMHOLE_PORTAL_FRAME)
        );

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(entries ->
            entries.method_45421(WORMHOLE_PORTAL_CONTROLLER)
        );

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(entries ->
            entries.method_45421(WORMHOLE_PORTAL_CHARGER)
        );

        CONTROLLER_BLOCK_ENTITY = class_2378.method_10230(
                class_7923.field_41181,
                class_2960.method_60655(Wormhole.MOD_ID, "wormhole_portal_controller"),
                FabricBlockEntityTypeBuilder.create(
                        (pos, state) -> new WormholeControllerBlockEntity(CONTROLLER_BLOCK_ENTITY, pos, state),
                        WORMHOLE_PORTAL_CONTROLLER
                ).build()
        );

        WORMHOLE_CHARGER_BLOCK_ENTITY = class_2378.method_10230(
                class_7923.field_41181,
                class_2960.method_60655(Wormhole.MOD_ID, "wormhole_portal_charger"),
                FabricBlockEntityTypeBuilder.create(
                        (pos, state) -> new WormholeChargerBlockEntity(WORMHOLE_CHARGER_BLOCK_ENTITY, pos, state),
                        WORMHOLE_PORTAL_CHARGER
                ).build()
        );
    }
}
