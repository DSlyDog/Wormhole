package com.reedwellarts.wormhole.registrar;

import com.reedwellarts.wormhole.Wormhole;
import com.reedwellarts.wormhole.items.item.HandheldPortalBattery;
import com.reedwellarts.wormhole.items.item.HandheldPortalItem;
import com.reedwellarts.wormhole.items.item.WormholeLinkerItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.function.Function;

public class ItemRegistrar {

    public static final class_1792 WORMHOLE_LINKER = register(
                "wormhole_linker",
                WormholeLinkerItem::new,
                new class_1792.class_1793().method_7889(1)
        );

    public static final class_1792 HANDHELD_PORTAL_BATTERY = register(
            "handheld_portal_battery",
            HandheldPortalBattery::new,
            new class_1792.class_1793().method_7889(1)
    );

    public static final class_1792 HANDHELD_PORTAL = register(
            "handheld_portal",
            HandheldPortalItem::new,
            new class_1792.class_1793()
                    .method_7889(1)
                    .method_7895(3)
                    .method_61648(HANDHELD_PORTAL_BATTERY)
    );

    private static class_1792 register(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings){
        class_2960 id = class_2960.method_60655(Wormhole.MOD_ID, name);
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, id);
        class_1792 item = factory.apply(settings.method_63686(key));
        return class_2378.method_39197(class_7923.field_41178, key, item);
    }

    public static void registerModItems(){
        Wormhole.LOGGER.info("Registering items for {}", Wormhole.MOD_ID);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries ->
            entries.method_45421(WORMHOLE_LINKER)
        );

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries ->
                entries.method_45421(HANDHELD_PORTAL)
        );

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries ->
                entries.method_45421(HANDHELD_PORTAL_BATTERY));
    }
}
