package com.reedwellarts.wormhole.registrar;

import com.reedwellarts.wormhole.Wormhole;
import com.reedwellarts.wormhole.screen.WormholeChargerScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class ScreenHandlerRegistrar {

    public static class_3917<WormholeChargerScreenHandler>  WORMHOLE_CHARGER_HANDLER = class_2378.method_10230(
            class_7923.field_41187,
            class_2960.method_60655(Wormhole.MOD_ID, "wormhole_charger_handler"),
            new ExtendedScreenHandlerType<>(
                    (syncId, playerInventory, pos) ->
                        new WormholeChargerScreenHandler(syncId, playerInventory),
                    class_2338.field_48404
            )
    );

    public static void registerScreenHandlers() {
        // load trigger
    }
}
