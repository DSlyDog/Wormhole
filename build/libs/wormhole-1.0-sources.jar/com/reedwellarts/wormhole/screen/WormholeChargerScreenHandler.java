package com.reedwellarts.wormhole.screen;

import com.reedwellarts.wormhole.registrar.ScreenHandlerRegistrar;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1719;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3913;
import net.minecraft.class_3919;
import org.jspecify.annotations.Nullable;

public class WormholeChargerScreenHandler extends class_1703 {

    private final class_1263 inventory;
    private final class_3913 properties;

    public WormholeChargerScreenHandler(int syncId, class_1661 playerInv) {
        this(syncId, playerInv, new class_1277(3), new class_3919(2));
    }

    public WormholeChargerScreenHandler(int syncId, class_1661 playerInventory, class_1263 inventory, class_3913 propertyDelegate){
        super(ScreenHandlerRegistrar.WORMHOLE_CHARGER_HANDLER, syncId);

        this.inventory = inventory;
        this.properties = propertyDelegate;

        method_17359(inventory, 3);
        inventory.method_5435(playerInventory.field_7546);
        method_17360(properties);

        method_7621(new class_1735(inventory, 0, 56, 17));
        method_7621(new class_1735(inventory, 1, 56, 53));
        method_7621(new class_1719(playerInventory.field_7546, inventory, 1, 116, 35));

        for (int row = 0; row < 3; row++){
            for (int col = 0; col < 9; col++){
                method_7621(new class_1735(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }

        for (int col = 0; col < 9; col++){
            method_7621(new class_1735(playerInventory, col, 8 + col * 18, 142));
        }
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return inventory.method_5443(player);
    }
}
