package com.reedwellarts.wormhole.util;

import com.reedwellarts.wormhole.Wormhole;
import com.reedwellarts.wormhole.items.blocks.BlockEntity.WormholeControllerBlockEntity;
import java.util.Optional;
import java.util.Set;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class TeleportUtil {

    public static void teleportToBase(class_3218 world, class_1297 entity, class_2338 destBase){
        class_2680 destState = world.method_8320(destBase);
        class_2350 facing = destState.method_28498(class_2741.field_12525)
                ? destState.method_11654(class_2741.field_12525)
                : class_2350.field_11043;

        class_2338 exitPos;
        if (world.method_8320(destBase.method_10093(facing)).method_26215()) {
            exitPos = destBase.method_10093(facing);
        }else{
            exitPos = destBase.method_10093(facing).method_10084();
        }

        class_243 center = class_243.method_24955(exitPos);

        float yaw = yawFromDirection(facing);
        entity.method_48105(world, center.field_1352, center.field_1351, center.field_1350, Set.of(), yaw, entity.method_36455(), false);
    }

    public static float yawFromDirection(class_2350 direction) {
        return switch (direction) {
            case field_11039  -> 90.0f;
            case field_11043 -> 180.0f;
            case field_11034  -> 270.0f;
            default    -> 0.0f;
        };
    }

    public static void wirePortal(class_3222 player, class_2338 controllerPos, String destinationName){
        class_3218 world = player.method_51469().method_8410();

        class_2586 blockEntity = world.method_8321(controllerPos);
        if (!(blockEntity instanceof WormholeControllerBlockEntity controllerBE)) {
            return;
        }

        class_2338 sourceBase = controllerBE.getLinkedBase();
        if (sourceBase == null){
            return;
        }

        WormholeLinkState linkState = WormholeLinkState.get(world);
        Optional<class_2338> destBaseOpt = linkState.getPortalPos(destinationName);
        if (destBaseOpt.isEmpty()){
            player.method_7353(
                    class_2561.method_43470("Portal '" + destinationName + "' no longer exists")
                            .method_27692(class_124.field_1061),
                    false
            );
            return;
        }

        class_2338 destBase = destBaseOpt.get();
        boolean opened = linkState.activatePortal(world, sourceBase, destBase);
        if (!opened){
            player.method_7353(
                    class_2561.method_43470("Could not open portal. Is the frame intact?")
                            .method_27692(class_124.field_1061),
                    false
            );
            return;
        }

        player.method_7353(
                class_2561.method_43470("Portal opened → " + destinationName)
                        .method_27692(class_124.field_1060),
                false
        );
    }

    public static void wireRemoteConnection(class_3222 player, String destinationName){
        WormholeLinkState linkState = WormholeLinkState.get(player.method_51469().method_8410());
        Optional<class_2338> destBaseOpt = linkState.getPortalPos(destinationName);
        class_1799 stack = player.method_6047();

        Wormhole.LOGGER.info("damage {}, max damage {}", stack.method_7919(), stack.method_7936());
        if (stack.method_7919() < stack.method_7936() - 1){
            Wormhole.LOGGER.info("Damaging item");
            class_1935 convertible = stack.method_7909();
            stack.method_60986(1, convertible, player, player.method_6058() == class_1268.field_5808
                    ? class_1304.field_6173
                    : class_1304.field_6171);
        } else if (stack.method_7919() == stack.method_7936() - 1){
            stack.method_7974(stack.method_7936());
        }

        if (destBaseOpt.isEmpty()){
            player.method_7353(
                    class_2561.method_43470("Portal '" + destinationName + "' no longer exists")
                            .method_27692(class_124.field_1061),
                    false
            );
            return;
        }

        teleportToBase(player.method_51469().method_8410(), player, destBaseOpt.get());
    }
}
